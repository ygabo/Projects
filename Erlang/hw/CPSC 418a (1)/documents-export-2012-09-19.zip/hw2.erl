-module(hw2).
-export([max_hr/1]).
-export([max_tr/1]).
-export([max_trh/2]).
-export([bigger/2]).

%homework 2 

max_hr([]) -> [];
max_hr([H|T]) -> bigger(H, max_hr(T)).

bigger([],Y) -> Y;
bigger(X,[]) -> X;
bigger(X,Y) when X >= Y -> X;
bigger(X,Y) when X < Y -> Y.

max_tr([]) -> [];
max_tr([H|T]) -> max_trh([H|T],H).

max_trh([],X) -> X;
max_trh([H|T], X) when H >= X -> max_trh(T, H);
max_trh([H|T], X) when H < X -> max_trh(T,X). 
